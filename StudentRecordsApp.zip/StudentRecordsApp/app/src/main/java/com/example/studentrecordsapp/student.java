package com.example.studentrecordsapp;

public class student {

    String id;
    String name;
    String course;
    String fee;
    String titles;
}
